import React from 'react';

function App() {
  // Стили для контейнера с деревянным фоном
  const appStyle = {
    backgroundColor: '#A0522D', // Коричневый цвет (дерево)
    width: '100vw',
    height: '100vh',
    margin: 0,
    padding: 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  };

  // Стили для формы окна
  const windowStyle = {
    width: '400px',
    height: '300px',
    backgroundColor: '#F5F5DC', // Светлый бежевый (стекло)
    borderRadius: '10px', // Закругленные углы
    boxShadow: '0 0 15px rgba(0, 0, 0, 0.5)', // Тень для объема
    border: '8px solid #8B4513', // Рамка коричневого цвета
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  };

  // Стили для перекладины окна
  const dividerStyle = {
    width: '80%',
    height: '4px',
    backgroundColor: '#8B4513',
    position: 'absolute',
  };

  return (
    <div style={appStyle}>
      <div style={windowStyle}>
        <div style={{...dividerStyle, top: '40%'}}></div>
        <div style={{...dividerStyle, top: '60%'}}></div>
      </div>
    </div>
  );
}

export default App;